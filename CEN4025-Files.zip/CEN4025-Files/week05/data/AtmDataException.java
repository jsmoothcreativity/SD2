package week05.data;

import week04.AtmException;

/**
 * Data Access Exception class
 * @author Scott LaChance
 *
 */
public class AtmDataException extends AtmException
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Default constructor
	 */
	public AtmDataException()
	{
		
	}

	/**
	 * Extends base class exception
	 * @param desc Error description
	 */
	public AtmDataException(String desc)
	{
		super(desc);
	}

	/**
	 * Extends base class exception
	 * @param exception Exception we are wrapping
	 */
	public AtmDataException(Throwable exception)
	{
		super(exception);
	}

	/**
	 * Extends base class exception
	 * @param desc Error description
	 * @param exception Exception we are wrapping
	 */
	public AtmDataException(String desc, Throwable exception)
	{
		super(desc, exception);
	}

	/**
	 * Extends base class exception
	 * @param desc Error description
	 * @param exception Exception we are wrapping
	 * @param enableSuppression enableSuppression
	 * @param writableStackTrace whether or not the stack trace should be writable
	 */
	public AtmDataException(String desc, Throwable exception, boolean enableSuppression,
			boolean writableStackTrace)
	{
		super(desc, exception, enableSuppression, writableStackTrace);
	}

}
