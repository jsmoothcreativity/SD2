-- MySQL dump 10.13  Distrib 5.6.24, for Win64 (x86_64)
--
-- Host: localhost    Database: atm
-- ------------------------------------------------------
-- Server version	5.6.26-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `account`
--

DROP TABLE IF EXISTS `account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL COMMENT 'User account is associated with',
  `name` varchar(45) NOT NULL COMMENT 'account name',
  `balance` double NOT NULL DEFAULT '0' COMMENT 'balance of the account',
  `last_update` datetime NOT NULL COMMENT 'Timestamp of last update. Provided by the caller',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=309 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account`
--

LOCK TABLES `account` WRITE;
/*!40000 ALTER TABLE `account` DISABLE KEYS */;
INSERT INTO `account` VALUES (6,1,'fredfred',2500,'2015-12-07 00:00:00'),(142,1,'Scott\'s Checking',500.25,'2015-11-03 10:45:44'),(144,11,'Chris Checking',200,'2015-11-03 10:45:45'),(152,886,'PickleAccount',6666.66,'2015-11-03 10:45:59'),(161,36,'Blue Account',2500,'2015-11-03 10:46:11'),(165,11,'Chris Checking',200,'2015-11-25 06:44:54'),(166,-1,'Default Account',0,'2015-11-25 06:45:06'),(167,-1,'Bob Checking',250,'2015-11-25 06:45:06'),(168,-1,'Default Account',0,'2015-11-25 06:45:06'),(171,36,'Blue Account',2500,'2015-11-25 06:45:22'),(176,11,'Chris Checking',200,'2015-11-25 07:03:31'),(177,-1,'Default Account',0,'2015-11-25 07:03:42'),(178,-1,'Bob Checking',250,'2015-11-25 07:03:42'),(179,-1,'Default Account',0,'2015-11-25 07:03:42'),(182,36,'Blue Account',2500,'2015-11-25 07:03:58'),(187,11,'Chris Checking',200,'2015-11-25 11:20:17'),(188,-1,'Default Account',0,'2015-11-25 11:20:28'),(189,-1,'Bob Checking',250,'2015-11-25 11:20:28'),(190,-1,'Default Account',0,'2015-11-25 11:20:28'),(193,36,'Blue Account',2500,'2015-11-25 11:20:43'),(198,11,'Chris Checking',200,'2015-11-25 11:40:47'),(199,-1,'Default Account',0,'2015-11-25 11:40:58'),(200,-1,'Bob Checking',250,'2015-11-25 11:40:58'),(201,-1,'Default Account',0,'2015-11-25 11:40:58'),(204,36,'Blue Account',2500,'2015-11-25 11:41:14'),(209,11,'Chris Checking',200,'2015-11-25 11:46:00'),(210,-1,'Default Account',0,'2015-11-25 11:46:11'),(211,-1,'Bob Checking',250,'2015-11-25 11:46:11'),(212,-1,'Default Account',0,'2015-11-25 11:46:11'),(215,36,'Blue Account',2500,'2015-11-25 11:46:26'),(220,11,'Chris Checking',200,'2015-11-25 11:48:34'),(221,-1,'Default Account',0,'2015-11-25 11:48:45'),(222,-1,'Bob Checking',250,'2015-11-25 11:48:45'),(223,-1,'Default Account',0,'2015-11-25 11:48:45'),(226,36,'Blue Account',2500,'2015-11-25 11:49:01'),(231,11,'Chris Checking',200,'2015-11-25 11:58:11'),(232,-1,'Default Account',0,'2015-11-25 11:58:23'),(233,-1,'Bob Checking',250,'2015-11-25 11:58:23'),(234,-1,'Default Account',0,'2015-11-25 11:58:23'),(237,36,'Blue Account',2500,'2015-11-25 11:58:38'),(242,11,'Chris Checking',200,'2015-11-25 12:04:54'),(243,-1,'Default Account',0,'2015-11-25 12:05:05'),(244,-1,'Bob Checking',250,'2015-11-25 12:05:05'),(245,-1,'Default Account',0,'2015-11-25 12:05:05'),(248,36,'Blue Account',2500,'2015-11-25 12:05:21'),(253,11,'Chris Checking',200,'2015-11-25 12:10:09'),(254,-1,'Default Account',0,'2015-11-25 12:10:20'),(255,-1,'Bob Checking',250,'2015-11-25 12:10:20'),(256,-1,'Default Account',0,'2015-11-25 12:10:20'),(259,36,'Blue Account',2500,'2015-11-25 12:10:35'),(264,11,'Chris Checking',200,'2015-11-25 12:32:26'),(265,-1,'Default Account',0,'2015-11-25 12:32:38'),(266,-1,'Bob Checking',250,'2015-11-25 12:32:38'),(267,-1,'Default Account',0,'2015-11-25 12:32:38'),(270,36,'Blue Account',2500,'2015-11-25 12:32:53'),(275,11,'Chris Checking',200,'2015-11-25 12:35:46'),(276,-1,'Default Account',0,'2015-11-25 12:35:58'),(277,-1,'Bob Checking',250,'2015-11-25 12:35:58'),(278,-1,'Default Account',0,'2015-11-25 12:35:58'),(280,-1,'Default Account',0,'2015-11-25 12:35:59'),(282,36,'Blue Account',2500,'2015-11-25 12:36:14'),(283,1,'ttt',2000,'2015-12-07 00:00:00'),(284,1,'finnfinn',2300,'2015-12-07 00:00:00'),(285,1,'gedged',35000,'2015-12-07 00:00:00'),(286,1,'HardHard',4000,'2015-12-07 00:00:00'),(287,1,'RamRam',4500,'2015-12-07 00:00:00'),(288,1,'TomTom',5000,'2015-12-07 00:00:00'),(289,18,'TestAccount1',1000,'2016-09-16 00:00:00'),(290,19,'TestAccount1',1000,'2016-09-16 00:00:00'),(293,22,'TestAccount1',1000,'2016-09-16 00:00:00'),(294,23,'TestAccount1',1000,'2016-09-16 00:00:00'),(295,24,'TestAccount1',1000,'2016-09-16 00:00:00'),(296,25,'TestAccount1',1000,'2016-09-16 00:00:00');
/*!40000 ALTER TABLE `account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `pin` int(11) NOT NULL,
  `first_name` varchar(45) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `last_update` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,1234,'Scott','LaChance','2015-08-22 11:57:11'),(2,5678,'John','Fisher','2015-11-03 10:46:11'),(3,1234,'Jim','Thomas','2015-12-07 00:00:00'),(4,1234,'James','Halle','2015-12-07 00:00:00'),(5,1234,'Teresa','Holt','2015-12-07 00:00:00'),(6,1234,'Geddes','James','2015-12-07 00:00:00'),(7,1234,'Hardaway','Clark','2015-12-07 00:00:00'),(8,1234,'Jason','Bourne','2015-12-07 00:00:00'),(14,1234,'Jalopy','LastTest','2016-09-16 00:00:00'),(15,1234,'Jalopy','LastTest','2016-09-16 00:00:00'),(16,1234,'Jalopy','LastTest','2016-09-16 00:00:00'),(17,1234,'Jalopy','LastTest','2016-09-16 00:00:00'),(18,1234,'Jalopy','LastTest','2016-09-16 00:00:00'),(22,1234,'Jalopy','LastTest','2016-09-16 00:00:00'),(23,1234,'Jalopy','LastTest','2016-09-16 00:00:00'),(24,1234,'Jalopy','LastTest','2016-09-16 00:00:00'),(25,1234,'Jalopy','LastTest','2016-09-16 00:00:00');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-09-18 17:56:07
