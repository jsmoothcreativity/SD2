package week05.util;

import week05.app.User;

/**
 * Provides the API for the application to initiate a login operation
 * @author Scott LaChance
 *
 */
public class AtmSecurity
{
	/**
	 * Manages ATM security capabilities
	 */
	public AtmSecurity()
	{
		
	}
	
	/**
	 * Login a user
	 * User provides their ATM card which contains their user info
	 * (first name, last name, account number).
	 * User enters pin.
	 * User must be a valid user for that account AND pin must be valid.
	 * 
	 * @param loginUser 
	 * @param pin Unique PIN tied to user
	 * @return true if valid user
	 */
	public boolean login(User loginUser, int pin)
	{
		boolean result = false;
		
		return result;
	}
}
