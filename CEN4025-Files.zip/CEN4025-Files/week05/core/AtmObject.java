package week05.core;

/** 
 * Base class for all ATM domain objects
 * @author Scott LaChance
 *
 */
public abstract class AtmObject
{

}
