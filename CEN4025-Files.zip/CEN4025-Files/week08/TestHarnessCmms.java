package week08;

import test.TestEngine;
import week08.app.AppTest;
import week08.data.DataAccessTest;
import week08.io.TestCommunications;

/**
 * File: TestHarness.java
 * @author Scott LaChance
 */
class TestHarnessCmms
{
    public static void main(String[] args)
    {
    	trace("Starting test...");

		trace(" -- setup test data");
    	TestEngine engine = new TestEngine();
    	//engine.addTest(new AppTest());
    	//engine.addTest(new DataAccessTest());
    	//engine.addTest(new TestLogging());
    	//engine.addTest(new TestLogIn());
    	engine.addTest(new TestCommunications());

    	engine.runTests();

    	trace("Completed test");
    }

	static private void trace(String msg)
	{
		System.out.println(msg);
	}
}