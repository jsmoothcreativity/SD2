package week08.data;

import java.sql.Connection;
import java.util.List;

import test.AbstractTestCase;
import week04.app.User;
import week04.app.Account;

/**
 * Implements the DataAccess test
 * 
 * @author Scott LaChance
 *
 */
public class DataAccessTest extends AbstractTestCase
{
	public DataAccessTest()
	{
		super("DataAccessTest");
	}
	

	@Override
	protected boolean runTest()
	{
		boolean result = true;
		try
		{
			testDataAccessCreation();
			
			User newUser = testAddUser();
			testUpdateUser(newUser);
			
			Account newAccount = testAddAccount(newUser);
			testUpdateAccount(newAccount);
			
			// clean up
			testRemoveAccount(newAccount.getAccountId());
			testRemoveUser(newUser.getUserId());
		}
		catch(AtmDataException ex)
		{
			trace("AtmDataException - " + ex.getMessage());
			ex.getStackTrace();		
			result = false;
		}
		catch(Exception ex)
		{
			trace("Exception - " + ex.getMessage());
			ex.getStackTrace();
			result = false;
		}
		
		trace(String.format(" return %s", result));
		return result;
	}

	public void testUpdateAccount(Account account)
			throws AtmDataException
	{
		trace("Test updating account ...");
		
		DataAccess da = DataAccess.getInstance();
		account.setName("Johnny's checking");
		Account savedAccount = da.saveAccount(account);
		Account actualAccount = da.getAccountById(savedAccount.getAccountId());
		
		if(actualAccount.equals(savedAccount))
		{
			trace(String.format("Successfully updated account - %s" , actualAccount.toString()));
		}
		else
		{
			//trace("Failed to updated account " + account.toString());
			trace(String.format("**** Failed to updated account\r\nexpected: %s\r\nactual %s ", savedAccount.toString(), actualAccount.toString()));
		}
		
	}
	
	private void testRemoveAccount(long accountId)
			throws AtmDataException
	{
		DataAccess da = DataAccess.getInstance();		
		
		if(da.deletetAccountById(accountId))
		{
			trace("Successfully deleted account");
		}
		else
		{
			trace("failed to delete account id: " + accountId);
		}
	}

	private Account testAddAccount(User user)
			throws AtmDataException
	{
		DataAccess da = DataAccess.getInstance();
		trace("Test adding account ...");
		Account account = new Account(user, "TestAccount1", 1000);
		List<Account> accountList = da.getAllAccounts();
		int preSaveCount = accountList.size();
		trace(String.format("Existing Acccounts count %d", preSaveCount));
		trace("Saving account - " + account.toString());
		Account savedAccount = da.saveAccount(account);
		trace(String.format("Saved account info %s", savedAccount.toString()));
		
		List<Account> postAccountList = da.getAllAccounts();
		int postSaveCount = postAccountList.size();
		trace(String.format("Updated Acccounts count %d", postSaveCount));
		
		boolean result = savedAccount.getAccountId() != -1 &&
				preSaveCount < postSaveCount;
		
		this.addResultMessage(String.format("testAddAccount %s",result));
		
		return savedAccount;
	}
	
	private void testDataAccessCreation()
			throws AtmDataException
	{
		DataAccess da = DataAccess.getInstance();
		da.connect();
		
		Connection conn = da.getConnection();
		
		trace("Connected to database: " + conn.toString());
	}
	
	private User testAddUser()
		throws AtmDataException
	{
		DataAccess da = DataAccess.getInstance();
		
		trace("Test adding user ...");
		User user = new User("FirstTest", "LastTest");
		User newUser = da.saveUser(user);
		
		trace("User saved: " + newUser.toString());
		
		List<User> userList = da.getUsers();
		
		if( userList.size() > 0 )
		{
			String msg = String.format("successful save: Count=%d", userList.size());
			trace(msg);
			dumpList(userList);
		}	
		else
		{
			trace(" failed to save user");
		}
		
		trace("Test adding user complete");
		
		return newUser;
	}
	
	public void testUpdateUser(User user)
			throws AtmDataException
	{
		trace("Test updating user ...");
		
		DataAccess da = DataAccess.getInstance();
		user.setFirstName("Jalopy");
		User savedUser = da.saveUser(user);
		
		trace("Successfully updated user " + savedUser.toString());
	}
	
	public void testRemoveUser(long id)
			throws AtmDataException
	{
		trace("Test deleting user id - " + id);
		DataAccess da = DataAccess.getInstance();
		
		if(da.deletetUserById(id))
		{
			trace("Successfully deleted user");
		}
		else
		{
			trace("failed to delete user id: " + id);
		}
		
	}
	
	private void dumpList(List<User> list)
	{
		for(User user : list)
		{
			trace(user.toString());
		}
	}



}
