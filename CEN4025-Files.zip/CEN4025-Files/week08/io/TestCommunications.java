package week08.io;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.StringWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import java.lang.Thread;

import test.AbstractTestCase;
import week08.util.LoginRequest;

public class TestCommunications extends AbstractTestCase
{

	public TestCommunications()
	{
		super("TestCommunications");
		// TODO Auto-generated constructor stub
	}

	@Override
	protected boolean runTest()
	{
		boolean result = true;
		ServerThread server = null;
		CommEndPoint endPoint = null;
		BufferedReader in;
		try
		{
			in = new BufferedReader(new InputStreamReader(System.in));
			// trace("initialize the server");
			// initiate the server
			// server = new ServerThread();
			// server.start();
			// trace("server startedr");
			trace("create sender connection");
			Socket a = new Socket("localhost", 1001);
			sender = new CommEndPoint("SenderClient", a, this);
			Thread t = new Thread(sender);
			t.start();
			trace("created sender connection");
			LoginRequest request = new LoginRequest(1234, 6);
			// String response =
			trace("sending data (login request)");
			sender.sendData(request);
			
			String cmdline = "";
			while((cmdline = in.readLine()) != null)
			{
				if(cmdline.trim().equals("quit"))
				{
					break;
				}
				else
				{
					trace("request sent pausing - pausing main thread");
					synchronized (this)
					{
						this.wait();
					}
					trace("main thread running - getting data");

					String response = sender.getReceivedData();
					trace(response);
				}
			}
		}

		catch(AtmCommException ex)
		{
			traceException(ex);
			result = false;
		}
		catch(UnknownHostException ex)
		{
			traceException(ex);
			result = false;
		}
		catch(IOException ex)
		{
			traceException(ex);
			result = false;
		}
		catch(InterruptedException ex)
		{
			traceException(ex);
			result = false;
		}
		finally
		{
			trace("TestCommunications finally clause - cleaning up");
			try
			{
				if(receiver != null)
					receiver.quit();
				if(server != null)
					server.quit();

			}
			catch(RuntimeException ex)
			{
				ex.printStackTrace();
			}
			catch(Exception ex)
			{
				ex.printStackTrace();
			}

		}

		return result;
	}

	private void traceException(Exception ex)
	{
		java.io.StringWriter sWriter = new StringWriter();
		java.io.PrintWriter pWriter = new java.io.PrintWriter(sWriter);
		ex.printStackTrace(pWriter);
		String msg = String.format("Error during TestCommunications - %s\r\n%s",
				ex.getMessage(), sWriter.toString());
		trace(msg);
	}

	private CommEndPoint sender = null;
	private CommEndPoint receiver = null;

	class ServerThread extends Thread
	{
		@Override
		public void run()
		{
			execute();
		}

		private void execute()
		{
			initializeServer();

			startListening();
		}

		public void quit()
		{
			trace("Quitting server thread");
			try
			{
				if(server != null)
					server.close();
			}
			catch(IOException e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		/**
		 * Initialize the server. If server can't be initialized (socket error)
		 * then the app exits.
		 */
		private void initializeServer()
		{
			// Utilize error handling
			try
			{
				server = new ServerSocket(
						m_port); /* start listening on the port */
				trace("Initialized server on port: "
						+ Integer.toString(m_port));
			}
			catch(IOException e)
			{
				System.err.println("Could not listen on port: " + m_port);
				System.err.println(e);
				System.exit(1);
			}
		}

		/**
		 * This supports multiple clients connecting to it. The server method
		 * accept() blocks until a client requests a connection. At that point
		 * the method returns and assigns a Socket instance to the client
		 * variable. This client instance is then wrapped in the ClientConn
		 * object which handles the communications between client and the
		 * server. A thread is used to handle this communication The listener
		 * goes back and listens for another client.
		 * 
		 */
		private void startListening()
		{
			Socket client = null;
			while(true)
			{
				try
				{
					client = server.accept();
				}
				catch(IOException e)
				{
					System.err.println("Accept failed.");
					System.err.println(e);
					System.exit(1);
				}

				trace("accept succeeded");
				// start a new thread to handle this client
				try
				{
					receiver = new CommEndPoint("Client", client, this);
				}
				catch(AtmCommException e)
				{
					// TODO Auto-generated catch block
					e.printStackTrace();

				}
				// t.start();
			}
		}

		/** port to listen on */
		private int m_port = 1001;

		/**
		 * We use the ServerSocket to create a listener on a specific port
		 */
		private ServerSocket server = null;
	}
}
