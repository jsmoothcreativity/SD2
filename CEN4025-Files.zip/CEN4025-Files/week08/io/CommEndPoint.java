package week08.io;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.net.Socket;
//import java.util.ArrayList;
//import java.util.Arrays;
import java.util.logging.Logger;

import org.jdom2.Document;

import week08.TestLogging;
import week08.AtmException;
import week08.core.AtmObject;
import week08.xml.XmlUtility;

import java.io.IOException;

/**
 * This class implements the communications to send a data package across a
 * connection.
 * 
 * <table>
 * <tr>
 * <td>Message Type</td>
 * <td>Data (Y/N)</td>
 * </tr>
 * <tr>
 * <td>RTS</td>
 * <td>N)</td>
 * </tr>
 * <tr>
 * <td>RTR</td>
 * <td>N</td>
 * </tr>
 * <tr>
 * <td>SND</td>
 * <td>Y</td>
 * </tr>
 * <tr>
 * <td>ACK</td>
 * <td>N</td>
 * </tr>
 * </table>
 * 
 * @author Scott LaChance
 *
 */
public class CommEndPoint implements Runnable
{
	private final static Logger logger = Logger
			.getLogger(TestLogging.class.getName());

	private static final class Lock
	{
	}

	private final Object lock = new Lock();

	enum STATE
	{
		IDLE, READY_TO_SEND, READY_TO_RECEIVE, WAIT_DATA, WAIT_ACK, ERROR
	};

	// Three character message types/events
	enum EVENTS
	{
		RTS, RTR, SND, ACK, NOT_SET
	}

	// Data format that is is prefixed by three character message type
	// which is the same as the EVENTS enumeration and an optional payload
	// EVENTS|DATA
	private static String MSG_FMT = "%s%s";

	/**
	 * Created by the listener.
	 * 
	 * @param conn
	 *            The socket to communication over
	 * @throws AtmCommException
	 */
	public CommEndPoint(String name, Socket conn, Object parent)
			throws AtmCommException
	{
		m_socket = conn;
		m_curState = STATE.IDLE;
		m_name = name;
		m_parent = parent;
		
		trace(name + " constructor " + this.toString() + " - " + conn.toString());
		try
		{
			trace("CommEndPoint Constructor start");
			/* obtain an input stream to this client ... */
			m_reader = new BufferedReader(
					new InputStreamReader(m_socket.getInputStream()));
			m_readerThread = new ReadThread(m_reader);
			/* ... and an output stream to the same client */
			m_writer = new PrintWriter(m_socket.getOutputStream(), true);
			m_writerThread = new WriteThread(m_writer);

		}
		catch(IOException ex)
		{
			traceException(ex);
			throw new AtmCommException("Error initializing CommEndPoint", ex);
		}
//		catch(InterruptedException ex)
//		{
//			traceException(ex);
//			throw new AtmCommException("Error initializing CommEndPoint", ex);
//		}
		finally
		{
		}

		trace("CommEndPoint Constructor end");
	}
	

	@Override
	public void run()
	{
		trace("starting reader thread");
		m_readerThread.start();
//		synchronized (this)
//		{
//			try
//			{
//				this.wait(1000);
//			}
//			catch(InterruptedException e)
//			{
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
//		}

		trace("starting writer thread");
		m_writerThread.start();	
	}

	public void quit()
	{
		trace("CommEndPoint quit");
		try
		{
			if(m_reader != null)
				m_reader.close();
			if(m_writer != null)
				m_writer.close();
			if(m_socket != null)
				m_socket.close();
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}

	/**
	 * Convert the AtmObject to an XML text string and initiate the
	 * communications protocol
	 * 
	 * @param obj
	 */
	public void sendData(AtmObject obj)
	{
		try
		{
			trace("CommEndPoint sendData start");
			Document dom = XmlUtility.objectToXml(obj);
			String xml = XmlUtility.xmlDomToXmlString(dom);

			m_sendData = xml; // put the data into a variable the write thread
								// can access

			handleEvent(EVENTS.RTS);

		}
		catch(IOException ex)
		{
			traceException(ex);
		}
		catch(AtmException ex)
		{
			traceException(ex);
		}
		trace("CommEndPoint sendData end");
		// trace("Received data: " + this.getReceivedData());
		// return this.getReceivedData();
	}

	private void handleEvent(EVENTS event) throws IOException
	{
		trace(String.format("handleEvent Event: %s - current state: %s enter",
				event, m_curState));
		switch(event)
		{
			case NOT_SET:
				break;

			case RTR: // receiver action
				switch(m_curState)
				{
					case ERROR:
						break;
					case IDLE:
						m_curState = STATE.WAIT_DATA; // client is ready to
														// receive
						sendMessage(event); // send message to sender
						break;

					case READY_TO_RECEIVE: // deprecated
						break;

					case READY_TO_SEND: // sender is waiting for the client
										// response
						// send the data to the receiver
						m_curState = STATE.WAIT_ACK;
						sendMessage(EVENTS.SND);
						break;

					case WAIT_ACK:
						break;
					case WAIT_DATA:
						break;
					default:
						break;

					//
				}
				break;

			case RTS: // sender action
				trace(" CommEndpoint - Sending message "
						+ EVENTS.RTS.toString());
				m_curState = STATE.READY_TO_SEND;
				sendMessage(EVENTS.RTS);
				trace(" CommEndpoint - Message sent ");
				m_readerThread.interrupt();
				break;

			case SND:
				switch(m_curState)
				{
					case ERROR:
						break;
					case IDLE:
						break;

					case READY_TO_RECEIVE: // deprecated
						break;

					case READY_TO_SEND: // sender is waiting for the client
										// response
						// send the data to the receiver
						m_curState = STATE.WAIT_ACK;
						sendMessage(EVENTS.SND);
						break;

					case WAIT_ACK:
						break;

					case WAIT_DATA:
						// Received data
						trace(getReceivedData());
						sendMessage(EVENTS.ACK); // notify sender we received it
						break;
					default:
						break;
				}
				break;

			case ACK:
				switch(m_curState)
				{
					case WAIT_ACK:
						// send complete with the receiver
						m_curState = STATE.IDLE;
						m_parent.notify(); // unblock the parent so they can get
											// data
						break;
					case ERROR:
					case IDLE:
					case READY_TO_RECEIVE:
					case READY_TO_SEND:
					case WAIT_DATA:
					default:
						String errMsg = String.format(
								"ACK received in unexpected state: %s",
								m_curState);
						trace(errMsg);
						break;

				}
				break;
			default:
				break;

		}

		trace(String.format("handleEvent Event end: %s - current state: %s",
				event, m_curState));
	}

	private void sendMessage(EVENTS msg)
	{
		trace(" sendMessage enter - " + msg.toString());
		switch(msg)
		{
			case RTS: // notify the receiver we want to send
				setCurrentMessageType(msg); // set the message type
				synchronized (lock)
				{
					lock.notify(); // unblock the writer
				}
				break;

			case RTR: // receiver is responding to sender
				setCurrentMessageType(msg); // set the message type
				synchronized (lock)
				{
					lock.notify(); // unblock the writer
				}
				break;

			case SND: // sender sends data to receiver
				setCurrentMessageType(msg); // set the message type
				synchronized (lock)
				{
					lock.notify(); // unblock the writer
				}
				break;

			case ACK: // receiver notifies sender data was received
				setCurrentMessageType(msg); // set the message type
				synchronized (lock)
				{
					lock.notify(); // unblock the writer
				}
				break;

			default:
				break;
		}

		trace(" sendMessage exit");
	}

	private void setCurrentMessageType(EVENTS msg)
	{
		synchronized (this)
		{
			m_curMsgType = msg;
		}
	}

	/**
	 * We need this to be thread-safe. The set and get are synchronized for this
	 * reason
	 * 
	 * @return Current message type or NOT_SET if message type isn't specified
	 */
	private EVENTS getCurrentMessageType()
	{
		EVENTS curEvent = EVENTS.NOT_SET;
		synchronized (this)
		{
			curEvent = m_curMsgType;
		}

		return curEvent;
	}

	public String getReceivedData()
	{
		String data = "";
		synchronized (this)
		{
			data = m_receivedData;
		}

		return data;
	}

	private void setReceiveData(String data)
	{
		synchronized (this)
		{
			m_receivedData = data;
		}
	}

	private void trace(String msg)
	{
		String fmtMsg = String.format("%s - %s", m_name, msg);
		System.out.println(fmtMsg);
		// logger.info(fmtMsg);
	}

	private void traceException(Exception ex)
	{
		java.io.StringWriter sWriter = new StringWriter();
		java.io.PrintWriter pWriter = new java.io.PrintWriter(sWriter);
		ex.printStackTrace(pWriter);
		String msg = String.format("Error in CommEndPoint %s - %s\r\n%s",
				m_name, ex.getMessage(), sWriter.toString());
		trace(msg);
		// logger.info(msg);
	}

	private WriteThread m_writerThread;
	private ReadThread m_readerThread;
	private STATE m_curState = STATE.IDLE;
	private Socket m_socket;
	private BufferedReader m_reader; // receives data from other endpoint
	private PrintWriter m_writer; // send data to other endpoint

	private String m_sendData;
	private String m_receivedData;
	private EVENTS m_curMsgType;
	private String m_name; // Alias for this instance
	private Object m_parent;

	/**
	 * This class listens for data to be sent from the other endpoint. It
	 * decodes the response and converts it to an EVENTS enumeration which
	 * corresponds to the message type.
	 * 
	 * @author Scott LaChance
	 *
	 */
	class ReadThread extends Thread
	{
		ReadThread(BufferedReader reader)
		{
			m_reader = reader;
		}

		@Override
		public void run()
		{
			trace(" ReadThread running");
			try
			{
				while(!m_fDone)
				{
					trace(" ReadThread waiting for a message");
					String response = m_reader.readLine();
					trace(" ReadThread received a message: " + response);
					handleResponse(response);
				}
			}
			catch(IOException ex)
			{
				traceException(ex);
			}

			trace(" ReaderThread exiting");
		}

		public void end()
		{
			m_fDone = true;
		}

		private void handleResponse(String response) throws IOException
		{
			trace("handleResponse: " + response);
			EVENTS msg = EVENTS.NOT_SET;
			if(response.startsWith(EVENTS.SND.toString()))
			{
				trace("this is a send data event with a data payload");
				// this is a send data event with a data payload
				msg = EVENTS.SND;
				String receivedData = response.substring(3); // skip the message
																// portion
				setReceiveData(receivedData);
			}
			else
			{
				// non-data response
				msg = EVENTS.valueOf(response);
			}

			trace(String.format("ReadThread Message Type: %s - state: %s", msg,
					m_curState));
			switch(msg)
			{

				case RTR: // received by the sender so we can send the data
					handleEvent(EVENTS.RTR);
					break;

				case RTS:
					// send ready to receive
					handleEvent(EVENTS.RTR);
					break;

				case SND:
					// sender is sending data
					handleEvent(EVENTS.SND);
					break;

				case ACK:
					// receiver received data
					handleEvent(EVENTS.ACK);
					break;

				default:
					break;

			}
		}

		private BufferedReader m_reader; // receives data from other endpoint
		private boolean m_fDone = false;
	}

	/**
	 * The purpose of this class is to wait to send data It gets needs two
	 * pieces of data that are set outside its thread context: the message type
	 * and any data payload. Only this class actually calls the m_writer
	 * instance
	 * 
	 * @author Scott LaChance
	 *
	 */
	class WriteThread extends Thread
	{
		WriteThread(PrintWriter writer)
		{
			m_writer = writer;
		}

		@Override
		public void run()
		{
			// get the send buffer
			try
			{
				while(!m_fDone)
				{
					// while (!isWakeupNeeded()) {
					// lock.wait();
					// }

					synchronized (lock)
					{
						trace("Pausing write thread");
						lock.wait();
					}

					trace(" WriteThread - processing");
					m_fDone = process();
					trace(" WriteThread - processing complete - fDone flag " + m_fDone);
				}
			}
			catch(InterruptedException ex)
			{
				traceException(ex);
			}

			trace(" WriteThread exiting");
		}

		/**
		 * This can be called asynchronously.
		 */
		public void end()
		{
			m_fDone = true;
			this.notify(); // unblock the thread so it can terminate
		}

		private boolean process()
		{

			boolean fDone = false;
			EVENTS curMessage = getCurrentMessageType();
			trace(" WriteThread process() msg: " + curMessage.toString());
			switch(curMessage)
			{
				case ACK:
					m_writer.write(curMessage.toString());
					m_writer.flush();
					break;

				case RTR:
					m_writer.write(curMessage.toString());
					m_writer.flush();
					break;

				case RTS:
					m_writer.write(curMessage.toString());
					m_writer.flush();
					break;

				case SND:
					// format the MSG_TYPE|DATA packet
					String packet = String.format(MSG_FMT,
							curMessage.toString(), m_sendData);
					m_writer.write(packet);
					m_writer.flush();
					break;

				case NOT_SET:
					// NO OP
					logger.info("WriteThread received NOT_SET message type");
					break;

				default:
					// NO OP
					break;

			}
			trace(" WriteThread process() end ");
			return fDone;
		}

		private PrintWriter m_writer; // send data to other endpoint
		private boolean m_fDone = false;
	}

}
