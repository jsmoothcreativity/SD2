package week08.app;

import test.AbstractTestCase;

/**
 * Implements the test for User and Account classes
 * 
 * @author Scott LaChance
 *
 */
public class AppTest extends AbstractTestCase
{
	public AppTest()
	{
		super("AppTest");
		// TODO Auto-generated constructor stub
	}

	@Override
	protected boolean runTest()
	{
		boolean userTest = testUserClassEquals();
		boolean accountTest = testAccountEquals();
		return userTest && accountTest;
	}

	private boolean testAccountEquals()
	{
		trace("Testing Account class and equals");
		boolean equalTest = true;

		// simple user creation
		User user = new User();

		Account account1 = new Account(user,"Account1", 1000);
		Account account2 = new Account(user,"Account1", 1000);

		trace(String.format("Test accounts %s, %s", account1.toString(), account2.toString()));
		
		// expect to be same
		if(!account1.equals(account2))
		{
			equalTest = false;
		}
		
		account2.setName("Account2");
		// expect to be different
		if(account1.equals(account2))
		{
			equalTest = false;
			trace(String.format("Expected accounts to be different %s, %s", account1.toString(), account2.toString()));
		}
		
		return equalTest;
	}

	private boolean testUserClassEquals()
	{
		trace("Testing User class and equals");
		boolean equalTest = true;

		// simple user creation
		User user = new User();
		trace(user.toString());

		User user2 = new User();
		trace(user2.toString());

		// expect to be same
		if(!user.equals(user2))
		{
			equalTest = false;
		}

		user2.setFirstName("Jim");
		user2.setLastName("Bo");
		user2.setUserId(1);
		trace(user2.toString());

		// expect to be different
		if(user.equals(user2))
		{
			equalTest = false;
		}

		User user3 = new User(user2.getUserId(), user2.getFirstName(),
				user2.getLastName());
		trace(user3.toString());

		// expect to be same
		if(!user3.equals(user2))
		{
			equalTest = false;
		}

		return equalTest;
	}

}
