package week12.data;

import java.util.ArrayList;
import java.util.List;

import java.util.UUID;

/**
 * Generates a universally unique id across the system. Accounts for multiple
 * instances across the system.
 * 
 * @author scottl
 * @version 1.0
 * updated 24-Aug-2014 2:04:49 PM
 */
public class SystemIdGenerator
{
	/**
	 * Default constructor
	 * By making this private you can't instantiate the
	 * class.
	 */
	private SystemIdGenerator()
	{
	}

	/**
	 * provides a thread-safe generation of the new GUID
	 * 
	 * @return New UUID formatted as a string
	 *         (f81d4fae-7dec-11d0-a765-00a0c91e6bf6)
	 */
	public static String getUuid()
	{
		synchronized (m_privateInstance)
		{
			UUID newUuid = UUID.randomUUID();
			return newUuid.toString();
		}
	}
	
	/**
	 * There are often occasions when users need a batch of identifiers.
	 * This provides a unique set of IDs
	 * 
	 * @param numberOfUuids Number of UUIDs to generate
	 * @return List of Uuid Strings
	 */
	public static List<String> getUuidBatch(int numberOfUuids)
	{
		ArrayList<String> listOfUuids = new ArrayList<String>();
		
		synchronized (m_privateInstance)
		{
			for(int index = 0; index < numberOfUuids; index++)
			{
				listOfUuids.add(UUID.randomUUID().toString());
			}
		}
		
		return listOfUuids;
	}
	
	// Static initializer
	static
	{
		m_privateInstance = new SystemIdGenerator();
	}
	
	private static SystemIdGenerator m_privateInstance;
}// end SystemIdGenerator