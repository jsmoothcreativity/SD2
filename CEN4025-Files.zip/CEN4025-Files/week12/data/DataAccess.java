package week12.data;

import java.io.StringWriter;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Calendar;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

import week12.util.AtmInvalidUserException;
import week12.util.AtmLogger;
import week12.app.Account;
import week12.app.User;


import java.sql.SQLException;

/**
 * Provides the interface to the datastore For this implementation that is a
 * MySql database
 * 
 * @author scottl
 * 
 */
public class DataAccess
{
	private final static Logger logger = 
			Logger.getLogger(AtmLogger.ATM_LOGGER + "." + DataAccess.class.getName());

	/**
	 * Private Constructor This cannot be instantiated
	 */
	private DataAccess(String username, String password)
	{
		m_userName = username;
		m_password = password;
	}
	
	// Factory methods	
	/**
	 * Factory method to return a DataAccess instance. Uses the default user and
	 * password
	 * 
	 * @return Singleton instance of the DataAccess object.
	 * @throws AtmDataException
	 *             on error
	 */
	public static DataAccess getInstance() throws AtmDataException
	{
		// pass the defaults to the parameterized method
		return getInstance(DEFAULT_USER, DEFAULT_PASS);
	}

	/**
	 * Factory method to return a DataAccess instance. Uses the default user and
	 * password
	 * 
	 * @param username
	 *            User name
	 * @param password
	 *            User password
	 * @return Singleton instance of the DataAccess object.
	 * @throws AtmDataException
	 *             on error
	 */
	public static synchronized DataAccess getInstance(String username,
			String password) throws AtmDataException
	{
		if(m_dataAccess == null)
		{
			m_dataAccess = new DataAccess(username, password);
		}

		return m_dataAccess;
	}
	/**
	 * Saves an account
	 * 
	 * @param account
	 *            The account to save
	 * @throws AtmDataException
	 *             if there is a save error
	 * @throws AtmInvalidUserException if associated user doesn't exist
	 */
	public Account saveAccount(Account account) throws AtmDataException, AtmInvalidUserException
	{
		Calendar now = Calendar.getInstance();   // Gets the current date and time.
		Date updateDate = new java.sql.Date(now.getTime().getTime());
		Account savedAccount = account;

		if( account.getAccountId() == -1)
		{
			savedAccount = insertAccount(account, updateDate);
		}
		else
		{
			savedAccount = updateAccount(account, updateDate);
		}

		return savedAccount;
	}

	/**
	 * Get the requested Account
	 * 
	 * @param user
	 *            User reference
	 * @return An Account reference
	 * @throws AtmDataException
	 */
	public List<Account> getUserAccounts(User user) throws AtmDataException
	{
		List<Account> accounts = new ArrayList<Account>();
		try
		{
			m_selectAccountByUseridStatement.setLong(1, user.getUserId());
			ResultSet resultSet = m_selectAccountByUseridStatement.executeQuery();
			
			while(resultSet.next())
			{
				long id = resultSet.getLong("id");
				String name = resultSet.getString("name");
				double balance = resultSet.getDouble("balance");

				accounts.add(new Account(id, user, name, balance));
			}
		}
		catch(SQLException ex)
		{
			throw new AtmDataException(ex);
		}

		return accounts;
	}
	
	/**
	 * Get the requested Account
	 * @param accountId Account ID to retrieve
	 * @return An Account reference
	 * @throws AtmDataException on error
	 * @throws AtmInvalidUserException if user doesn't exist
	 */
	public Account getAccountById(long accountId)
		throws AtmDataException, AtmInvalidUserException
	{
		Account account = null;
		
		ResultSet resultSet = null;

		try
		{
			m_selectAccountByIdStatement.setLong(1, accountId);
			resultSet = m_selectAccountByIdStatement.executeQuery();

			if(resultSet.next())
			{
				long id = resultSet.getLong("id");
				long userId = resultSet.getLong("user_id");
				User associatedUser = getUserById(userId);
				String accountName = resultSet.getString("name");
				double balance = resultSet.getDouble("balance");

				account = new Account(id, associatedUser, accountName, balance);
			}
		}
		catch(SQLException ex)
		{
			java.io.StringWriter sWriter = new StringWriter();
			java.io.PrintWriter pWriter = new java.io.PrintWriter(sWriter);
			ex.printStackTrace(pWriter);
			logger.warning(String.format("Error getting account by id id: %d\r\nerror info %s\r\n%s", accountId, ex.getMessage(), sWriter.toString()));
			// log error
			ex.printStackTrace();
			throw new AtmDataException(ex);
		}
	
		return account;
	}


	/**
	 * Gets all the accounts in a list
	 * 
	 * @return List of Accounts
	 * @throws AtmDataException on error
	 * @throws AtmInvalidUserException if user doesn't exist
	 */
	public List<Account> getAllAccounts() throws AtmDataException, AtmInvalidUserException
	{
		List<Account> accounts = new ArrayList<Account>();
		ResultSet resultSet = null;

		try
		{
			resultSet = m_selectAllAccountsStatement.executeQuery();

			while(resultSet.next())
			{
				long id = resultSet.getLong("id");
				long userId = resultSet.getLong("user_id");
				User user = getUserById(userId);
				String name = resultSet.getString("name");
				double balance = resultSet.getDouble("balance");

				accounts.add(new Account(id, user, name, balance));
			}
		}
		catch(SQLException ex)
		{
			// log error

			java.io.StringWriter sWriter = new StringWriter();
			java.io.PrintWriter pWriter = new java.io.PrintWriter(sWriter);
			ex.printStackTrace(pWriter);
			logger.warning(String.format("Error getting all account: nerror info %s\r\n%s", ex.getMessage(), sWriter.toString()));
			throw new AtmDataException(ex);
		}

		return accounts;
	}

//	/**
//	 * Save a user instance
//	 * @param user The User reference to save
//	 * @throws AtmDataException
//	 */
//	public void saveUser(User user) throws AtmDataException
//	{
//		Calendar now = Calendar.getInstance(); // Gets the current date and
//												// time.
//		Date updateDate = new java.sql.Date(now.getTime().getTime());
//
//		try
//		{
//			m_saveUserStatement.setLong(1, user.getUserId());
//			m_saveUserStatement.setString(2, user.getFirstName());
//			m_saveUserStatement.setString(3, user.getLastName());
//			m_saveUserStatement.setInt(4, user.getPin());
//			m_saveUserStatement.setDate(5, updateDate);
//			m_saveUserStatement.executeUpdate();
//		}
//		catch(SQLException ex)
//		{
//			throw new AtmDataException(ex);
//		}
//	}
	
	/**
	 * Save the provided user object. Uses the prepared statement to assign the
	 * contents of the object
	 * 
	 * @param user
	 *            A User reference to save
	 * @throws AtmDataException
	 *             on error
	 * @return new or updated User object
	 * @throws AtmDataException on error
	 * @throws AtmInvalidUserException if error occurs inserting/updating user
	 */
	public User saveUser(User user) throws AtmDataException, AtmInvalidUserException
	{
		Calendar now = Calendar.getInstance(); // Gets the current date and
												// time.
		User updatedUser = null;
		Date updateDate = new java.sql.Date(now.getTime().getTime());

		if(user.getUserId() == -1)
		{
			// insert new user
			updatedUser = insertUser(user, updateDate);
		}
		else
		{
			// update existing user
			updatedUser = updatetUser(user, updateDate);
		}

		return updatedUser;
	}

//	/**
//	 * Gets a user from the datastore.
//	 * 
//	 * @param userId The user id
//	 * @return A valid User reference
//	 * @throws AtmDataException
//	 * @throws AtmInvalidUserException
//	 */
//	public User getUser(long userId) throws AtmDataException,
//			AtmInvalidUserException
//	{
//		User user = null;
//		ResultSet resultSet = null;
//
//		try
//		{	
//			m_selectUserStatement.setLong(1, userId);	
//			resultSet = m_selectUserStatement.executeQuery();
//			if(resultSet.next())
//			{
//				long id = resultSet.getLong("id");
//				String first = resultSet.getString("first_name");
//				String last = resultSet.getString("last_name");
//				int pin = resultSet.getInt("pin");
//				user = new User(id, pin, first, last);			
//			}
//			else
//			{
//				throw new AtmInvalidUserException("No user for id " + Long.toString(userId));
//			}
//		}
//		catch(SQLException ex)
//		{
//			// log error
//			trace("DataAccess - SQLException " + ex.getMessage());
//			throw new AtmDataException(ex);
//		}
//		catch(Exception ex)
//		{
//			// log error
//			trace("DataAccess - Exception " + ex.getMessage());
//			throw new AtmDataException(ex);
//		}
//
//		return user;
//	}
	
	/**
	 * Retrieves a user by their ID
	 * 
	 * @param id
	 *            Id of the user to locate
	 * @return User reference of null if not found
	 * @throws AtmDataException
	 *             on error
	 * @throws AtmInvalidUserException if ID doesn't have a user
	 */
	public User getUserById(long id) throws AtmDataException, AtmInvalidUserException
	{
		User user = null;
		ResultSet resultSet = null;

		try
		{
			m_selectUserByIdStatement.setLong(1, id);
			resultSet = m_selectUserByIdStatement.executeQuery();

			if(resultSet.next())
			{
				long userId = resultSet.getLong("id");
				int pin = resultSet.getInt("pin");
				String first = resultSet.getString("first_name");
				String last = resultSet.getString("last_name");

				user = new User(userId, pin, first, last);
			}		
			else
			{
				throw new AtmInvalidUserException("No user for id " + Long.toString(id));
			}
		}
		catch(SQLException ex)
		{
			// log error
			ex.printStackTrace();
			throw new AtmDataException(ex);
		}

		return user;
	}


//	/**
//	 * Delete a user.
//	 * Used by the test harness.
//	 * This is a destructive delete.
//	 * @param user The user to delete
//	 * @throws AtmDataException
//	 */
//	public void deleteUser(User user) throws AtmDataException
//	{
//		try
//		{
//			m_deleteUserStatement.setLong(1, user.getUserId());
//			int count = m_deleteUserStatement.executeUpdate();
//			if( count == 0)
//			{
//				trace("User not deleted " + user.toString());
//			}
//		}
//		catch(SQLException ex)
//		{
//			throw new AtmDataException(ex);
//		}
//	}
	
	/**
	 * Deletes a user by their ID
	 * 
	 * @param id
	 *            Id of the user to delete
	 * @return true if deleted otherwise false
	 * @throws AtmDataException
	 *             on error
	 */
	public boolean deletetUserById(long id) throws AtmDataException
	{
		boolean result = false;

		try
		{
			m_deleteUserByIdStatement.setLong(1, id);
			int count = m_deleteUserByIdStatement.executeUpdate();
			
			result = count == 1 ? true : false;
			trace("delete user row count " + count);
			
			if(!result)
			{
				// log failed to delete
			}
		}
		catch(SQLException ex)
		{
			// log error

			java.io.StringWriter sWriter = new StringWriter();
			java.io.PrintWriter pWriter = new java.io.PrintWriter(sWriter);
			ex.printStackTrace(pWriter);
			logger.warning(String.format("Error deleting user by id id: %d\r\nerror info %s\r\n%s", id, ex.getMessage(), sWriter.toString()));
			throw new AtmDataException(ex);
		}

		return result;
	}

	/**
	 * Deletes a user by their ID
	 * 
	 * @param id
	 *            Id of the user to delete
	 * @return true if deleted otherwise false
	 * @throws AtmDataException
	 *             on error
	 */
	public boolean deletetAccountById(long id) throws AtmDataException
	{
		boolean result = false;

		try
		{
			m_deleteAccountByIdStatement.setLong(1, id);
			int count = m_deleteAccountByIdStatement.executeUpdate();
			
			result = count == 1 ? true : false;
			trace("delete account row count " + count);
			
			if(!result)
			{
				// log failed to delete
			}
		}
		catch(SQLException ex)
		{
			// log error

			java.io.StringWriter sWriter = new StringWriter();
			java.io.PrintWriter pWriter = new java.io.PrintWriter(sWriter);
			ex.printStackTrace(pWriter);
			logger.warning(String.format("Error deleting account by id id: %d\r\nerror info %s\r\n%s", id, ex.getMessage(), sWriter.toString()));
			throw new AtmDataException(ex);
		}

		return result;
	}	

//	/**
//	 * Get the list of all users.
//	 * @return Full list of users
//	 * @throws AtmDataException
//	 */
//	public List<User> getUsers() throws AtmDataException
//	{
//		List<User> userList = new ArrayList<User>();
//		ResultSet resultSet = null;
//
//		try
//		{
//			resultSet = m_selectUsersStatement.executeQuery();
//
//			while(resultSet.next())
//			{
//				long userId = resultSet.getLong("id");
//				String first = resultSet.getString("first_name");
//				String last = resultSet.getString("last_name");
//				int pin = resultSet.getInt("pin");
//
//				userList.add(new User(userId, pin, first, last));
//			}
//		}
//		catch(SQLException ex)
//		{
//			// log error
//			throw new AtmDataException(ex);
//		}
//
//		return userList;
//	}
	/**
	 * Gets all the users from the data store.
	 * 
	 * @return List of Users
	 * @throws AtmDataException
	 *             on error
	 */
	public List<User> getUsers() throws AtmDataException
	{
		List<User> userList = new ArrayList<User>();
		ResultSet resultSet = null;

		try
		{
			resultSet = m_selectAllUsersStatement.executeQuery();

			while(resultSet.next())
			{
				long userId = resultSet.getLong("id");
				int pin =  resultSet.getInt("pin");
				String first = resultSet.getString("first_name");
				String last = resultSet.getString("last_name");

				userList.add(new User(userId, pin, first, last));
			}
		}
		catch(SQLException ex)
		{
			// log error
			java.io.StringWriter sWriter = new StringWriter();
			java.io.PrintWriter pWriter = new java.io.PrintWriter(sWriter);
			ex.printStackTrace(pWriter);
			logger.warning(String.format("Error getting all users: error info %s\r\n%s", ex.getMessage(), sWriter.toString()));
			throw new AtmDataException(ex);
		}

		return userList;
	}

	/**
	 * Disconnects the data access connection
	 */
	public void disconnect()
	{
		try
		{
			trace("DataAccess - disconnect");
			m_connect.close();
		}
		catch(SQLException ex)
		{
			System.out.println(ex.getMessage());
		}
	}
	
//	/**
//	 * Establishes the connection to the database.
//	 * Loads the JDBC driver for MySQL
//	 * user and password are hard coded. Not a best practice.
//	 * Initializes all the prepared statements.
//	 * 
//	 * @throws AtmDataException
//	 */
//	public void connect() throws AtmDataException
//	{
//		try
//		{
//			trace("DataAccess - connect");
//			// this will load the MySQL driver, each DB has its own driver
//			Class.forName("com.mysql.jdbc.Driver");
//
//			// setup the connection with the DB.
//			m_connect = DriverManager
//					.getConnection("jdbc:mysql://localhost/atm?"
//							+ "user=root&password=mainroot");
//			//
//			// pre-compile prepared statements
//			//
//			m_saveUserStatement = m_connect.prepareStatement(INSERT_USER_SQL);
//			m_selectUserStatement = m_connect.prepareStatement(SELECT_USER_SQL);
//			m_selectUsersStatement = m_connect
//					.prepareStatement(SELECT_USERS_SQL);
//			m_deleteUserStatement = m_connect.prepareStatement(DELETE_USER_SQL);
//
//			m_selectAccountByUseridStatement = m_connect
//					.prepareStatement(SELECT_ACCOUNT_BY_USERID_SQL);
//		}
//		catch(SQLException ex)
//		{
//			// log exception
//			System.out.println(ex.getMessage());
//			throw new AtmDataException(ex);
//		}
//		catch(Exception ex)
//		{
//			// log exception
//			System.out.println(ex.getMessage());
//			throw new AtmDataException(ex);
//		}
//	}

	/**
	 * Establishes a connection
	 * 
	 * @throws AtmDataException on error
	 */
	public void connect() throws AtmDataException
	{
		try
		{
			// this will load the MySQL driver, each DB has its own driver
			Class.forName("com.mysql.jdbc.Driver");

			// setup the connection with the DB.
			String connectionString = String.format(CONN_FMT, m_userName,
					m_password);

			m_connect = DriverManager.getConnection(connectionString);

			//
			// pre-compile prepared statements
			//
			m_insertUserStatement = m_connect.prepareStatement(INSERT_USER_SQL);
			m_selectAllUsersStatement = m_connect
					.prepareStatement(SELECT_ALL_USERS_SQL);
			m_selectUserByIdStatement = m_connect
					.prepareStatement(SELECT_USER_BY_ID_SQL);
			m_deleteUserByIdStatement = m_connect
					.prepareStatement(DELETE_USER_BY_ID_SQL);
			m_updateUserByIdStatement = m_connect
					.prepareStatement(UPDATE_USER_BY_ID_SQL);
			m_lastInsertStatement = m_connect.prepareStatement(LAST_INSERT_ID);
			m_insertAccountStatement =  m_connect.prepareStatement(INSERT_ACCOUNT_SQL);
			m_updateAccountByIdStatement =  m_connect.prepareStatement(UPDATE_ACCOUNT_BY_ID_SQL);
			m_selectAllAccountsStatement =  m_connect.prepareStatement(SELECT_ALL_ACCOUNTS_SQL);
			m_selectAccountByIdStatement =  m_connect.prepareStatement(SELECT_ACCOUNT_BY_ID_SQL);
			m_deleteAccountByIdStatement =  m_connect.prepareStatement(DELETE_ACCOUNT_BY_ID_SQL);
		}
		catch(SQLException ex)
		{
			// log exception

			java.io.StringWriter sWriter = new StringWriter();
			java.io.PrintWriter pWriter = new java.io.PrintWriter(sWriter);
			ex.printStackTrace(pWriter);
			logger.warning(String.format("Error connect to database: error info %s\r\n%s", ex.getMessage(), sWriter.toString()));
			throw new AtmDataException(ex);
		}
		catch(Exception ex)
		{
			// log exception

			java.io.StringWriter sWriter = new StringWriter();
			java.io.PrintWriter pWriter = new java.io.PrintWriter(sWriter);
			ex.printStackTrace(pWriter);
			logger.warning(String.format("Error connecting to database: error info %s\r\n%s", ex.getMessage(), sWriter.toString()));
			throw new AtmDataException(ex);
		}
	}

	/**
	 * Provides access to the connection object.
	 * @return The Connection reference.
	 */
	public Connection getConnection()
	{
		return m_connect;
	}
	
	/**
	 * Private helper method that inserts a new user
	 * @param user User reference to insert
	 * @param updateDate Update date to use
	 * @return The updated user information including the updated ID
	 * @throws AtmDataException on error
	 * @throws AtmInvalidUserException  if user doesn't exist
	 */
	private User insertUser(User user, java.sql.Date updateDate)
			throws AtmDataException, AtmInvalidUserException
	{
		User newUser = null;
		try
		{
			m_insertUserStatement.setInt(1, 1234);
			m_insertUserStatement.setString(2, user.getFirstName());
			m_insertUserStatement.setString(3, user.getLastName());
			m_insertUserStatement.setDate(4, updateDate);

			int rowsInserted = m_insertUserStatement.executeUpdate();

			if(rowsInserted > 0)
			{
				ResultSet rs = m_lastInsertStatement.executeQuery();
				if(rs.next())
				{
					int newId = rs.getInt(1);
					newUser = getUserById(newId);
					if(newUser == null)
					{
						String msg = String.format("Failed to find new inserted user %s %s", user.getFirstName(), user.getLastName());
						throw new AtmDataException(msg);
					}
				}
			}
			else
			{
				String msg = String.format("Insert user %s %s failed", user.getFirstName(), user.getLastName());
				throw new AtmDataException(msg);
			}
		}
		catch(SQLException ex)
		{
			java.io.StringWriter sWriter = new StringWriter();
			java.io.PrintWriter pWriter = new java.io.PrintWriter(sWriter);
			ex.printStackTrace(pWriter);
			logger.warning(String.format("Error inserting user: error info %s\r\n%s", ex.getMessage(), sWriter.toString()));
			throw new AtmDataException(ex);
		}
		
		return newUser;
	}

	/**
	 * Private helper method that updates a user.
	 * User already exists so we are updating the user information using the user ID.
	 * @param user User reference to insert
	 * @param updateDate Update date to use
	 * @return The updated user information including the updated ID
	 * @throws AtmDataException on error
	 */
	private User updatetUser(User user, java.sql.Date updateDate)
			throws AtmDataException
	{
		try
		{
			m_updateUserByIdStatement.setString(1, user.getFirstName());
			m_updateUserByIdStatement.setString(2, user.getLastName());
			m_updateUserByIdStatement.setDate(3, updateDate);
			m_updateUserByIdStatement.setLong(4, user.getUserId());
			m_updateUserByIdStatement.executeUpdate();
		}
		catch(SQLException ex)
		{
			ex.printStackTrace();
			throw new AtmDataException(ex);
		}
		
		// if we get here the user updated successfully and the datastore matches the user contents
		return user;
	}

	/**
	 * 
	 * @param newAccount The new Account instance
	 * @param updateDate The date of the update
	 * @return The fully populated account with the correct ID
	 * @throws AtmDataException If a data error occurs
	 * @throws AtmInvalidUserException if the user doesn't exist
	 */
	private Account insertAccount(Account newAccount, java.sql.Date updateDate) throws AtmDataException, AtmInvalidUserException
	{
		Account insertedAccount = null;

		try
		{
			m_insertAccountStatement.setLong(1, newAccount.getUserId());
			m_insertAccountStatement.setString(2, newAccount.getName());
			m_insertAccountStatement.setDouble(3, newAccount.getBalance());
			m_insertAccountStatement.setDate(4, updateDate);

			int rowsInserted = m_insertAccountStatement.executeUpdate();

			if(rowsInserted > 0)
			{
				ResultSet rs = m_lastInsertStatement.executeQuery();
				if(rs.next())
				{
					int newId = rs.getInt(1);
					insertedAccount = getAccountById(newId);
					if(insertedAccount == null)
					{
						String msg = String.format("Failed to find new inserted account %s", newAccount.getName());
						throw new AtmDataException(msg);
					}
				}
			}
			else
			{
				String msg = String.format("Insert account %s failed", newAccount.getName());
				throw new AtmDataException(msg);
			}
		}
		catch(SQLException ex)
		{

			java.io.StringWriter sWriter = new StringWriter();
			java.io.PrintWriter pWriter = new java.io.PrintWriter(sWriter);
			ex.printStackTrace(pWriter);
			logger.warning(String.format("Error inserting account: error info %s\r\n%s", ex.getMessage(), sWriter.toString()));
			throw new AtmDataException(ex);
		}

		return insertedAccount;
	}
	
	private Account updateAccount(Account account, java.sql.Date updateDate) throws AtmDataException
	{
		try
		{
			m_updateAccountByIdStatement.setLong(1, account.getUser().getUserId());
			m_updateAccountByIdStatement.setString(2, account.getName());
			m_updateAccountByIdStatement.setDouble(3, account.getBalance());
			m_updateAccountByIdStatement.setDate(4, updateDate);
			m_updateAccountByIdStatement.setLong(5, account.getAccountId());
			m_updateAccountByIdStatement.executeUpdate();
		}
		catch(SQLException ex)
		{

			java.io.StringWriter sWriter = new StringWriter();
			java.io.PrintWriter pWriter = new java.io.PrintWriter(sWriter);
			ex.printStackTrace(pWriter);
			logger.warning(String.format("Error updating account by id - id: %d\r\nerror info %s\r\n%s", account.getAccountId(), ex.getMessage(), sWriter.toString()));
			throw new AtmDataException(ex);
		}
		
		return account;
	}

	private void trace(String msg)
	{
		System.out.println(msg);
	}

	private Connection m_connect = null;
	private String m_userName = DEFAULT_USER;
	private String m_password = DEFAULT_PASS;
	
	// User prepared statements
//	private PreparedStatement m_saveUserStatement;
//	private PreparedStatement m_selectUsersStatement;
//	private PreparedStatement m_selectUserStatement;
//	private PreparedStatement m_deleteUserStatement;

	// Account prepared statements
	private PreparedStatement m_selectAccountByUseridStatement;
	private PreparedStatement m_insertUserStatement;
	private PreparedStatement m_selectAllUsersStatement;
	private PreparedStatement m_selectUserByIdStatement;
	private PreparedStatement m_deleteUserByIdStatement;
	private PreparedStatement m_updateUserByIdStatement;
	private PreparedStatement m_lastInsertStatement;
	private PreparedStatement m_insertAccountStatement;
	private PreparedStatement m_updateAccountByIdStatement;
	private PreparedStatement m_selectAllAccountsStatement;
	private PreparedStatement m_selectAccountByIdStatement;
	private PreparedStatement m_deleteAccountByIdStatement;
	// User queries
//	private String INSERT_USER_SQL = "insert into  atm.user values (?, ?, ?, ?, ?)";
//	private String SELECT_USERS_SQL = "SELECT id, first_name, last_name, pin from atm.user";
//	private String SELECT_USER_SQL = "SELECT id, first_name, last_name, pin from atm.user where id=?";
//	private String DELETE_USER_SQL = "DELETE FROM atm.user where id=?";

	// Account queries
	private String SELECT_ACCOUNT_BY_USERID_SQL = "SELECT id, user_id, name, balance from atm.account where user_id=?";
	
	private static String INSERT_USER_SQL = "insert into atm.user(pin,first_name,last_name,last_update) values (?,?,?,?)";
	private static String SELECT_ALL_USERS_SQL = "SELECT id, pin, first_name, last_name from atm.user";
	private static String SELECT_USER_BY_ID_SQL = "SELECT id, pin, first_name, last_name from atm.user where id=?";
	private static String DELETE_USER_BY_ID_SQL = "DELETE FROM atm.user where id=?";
	private static String UPDATE_USER_BY_ID_SQL = "UPDATE atm.user SET first_name=?, last_name=?, last_update=? WHERE id=?";
	private static String LAST_INSERT_ID = "SELECT LAST_INSERT_ID();";
	private static String INSERT_ACCOUNT_SQL = "INSERT INTO  atm.account(user_id,name,balance,last_update) VALUES (?, ?, ?, ?)";
	private static String SELECT_ALL_ACCOUNTS_SQL = "SELECT id, user_id, name, balance FROM atm.account";
	private static String SELECT_ACCOUNT_BY_ID_SQL = "SELECT id, user_id, name, balance FROM atm.account WHERE id=?";
	private static String UPDATE_ACCOUNT_BY_ID_SQL = "UPDATE atm.account SET user_id=?, name=?, balance=?, last_update=? WHERE id=?";
	private static String DELETE_ACCOUNT_BY_ID_SQL = "DELETE FROM atm.account WHERE id=?";

	
	private static DataAccess m_dataAccess;
	private static String DEFAULT_USER = "root";
	private static String DEFAULT_PASS = "root";
	private static String CONN_FMT = "jdbc:mysql://localhost/atm?user=%s&password=%s";

}
