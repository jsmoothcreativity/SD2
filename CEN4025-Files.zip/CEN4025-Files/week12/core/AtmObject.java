package week12.core;

/** 
 * Base class for all ATM domain objects
 * @author scottl
 *
 */
public abstract class AtmObject
{

}
